//
//  ViewController.swift
//  Gamify_Inicio
//
//  Created by Luis Rollon Gordo on 8/12/16.
//  Copyright © 2016 EfectoApple. All rights reserved.
//

import UIKit
import FirebaseAuth

class ViewController: UIViewController {
    
    @IBOutlet weak var loginEmailField: UITextField!
    @IBOutlet weak var loginPasswordField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func signUpTapped(_ sender: UIButton) {
        
    
    }
    
    @IBAction func loginTapped(_ sender: UIButton) {


    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }

}


